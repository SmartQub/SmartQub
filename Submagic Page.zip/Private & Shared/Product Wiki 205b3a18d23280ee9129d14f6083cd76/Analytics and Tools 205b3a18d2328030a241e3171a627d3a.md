# Analytics and Tools

<aside>
💡 Notion Tip: Document the most important information your collaborators need to know about how your work is setup and what tools the team uses!

</aside>