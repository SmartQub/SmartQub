# New Page With Tags

<aside>
💡 Notion Tip: Tag pages to let collaborators know what they can expect to use the page for. You can add one or many tags to any page in a wiki.

</aside>