# Product Interviews

# Philosophy

Create a quote by typing `/quote` and pressing `enter`.

> Before you build a better mousetrap, it helps to know if there are any mice out there.
> 

**— Yogi Berra**

# Interview Question Database

You can also add an inline database to a page, and create different views of it. Below, click `Default View` to see the same info as a list. You can create as many views as you want.

[Untitled](Product%20Interviews%20205b3a18d2328079bde8ca6061afee79/Untitled%20205b3a18d232800086c2e1550a4badbb.csv)

# Further Reading

For more on databases, check out this [Notion guide](https://www.notion.so/fd8cd2d212f74c50954c11086d85997e?pvs=21).